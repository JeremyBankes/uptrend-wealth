create
    definer = admin@`%` procedure ReadTrades(IN UserId int)
BEGIN
    IF UserId > 0 THEN
        SELECT Trade.Id,
               Trade.EntryTime,
               Trade.Pair,
               Trade.Direction,
               Trade.EntryPrice,
               Trade.ExitPrice,
               Trade.ExitTime,
               IF(Trade.Direction,
                  Trade.ExitPrice - Trade.EntryPrice,
                  Trade.EntryPrice - Trade.ExitPrice) *
               Trade.PositionSize AS Profit
        FROM Trade
                 INNER JOIN Claim ON Trade.Id = Claim.TradeId
                 INNER JOIN Account ON Claim.AccountId = Account.Id
                 INNER JOIN User ON Account.Id = User.AccountId
        WHERE User.Id = UserId
        ORDER BY ExitTime;
    ELSE
        SELECT Trade.Id,
               Trade.EntryTime,
               Trade.Pair,
               Trade.Direction,
               Trade.EntryPrice,
               Trade.ExitPrice,
               Trade.ExitTime,
               IF(Trade.Direction,
                  Trade.ExitPrice - Trade.EntryPrice,
                  Trade.EntryPrice - Trade.ExitPrice) *
               Trade.PositionSize AS Profit
        FROM Trade
        ORDER BY ExitTime;
    END IF;
END;

