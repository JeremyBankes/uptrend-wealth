create
    definer = admin@`%` procedure GetTradeProfit(IN UserID int, IN StartDate datetime, IN EndDate datetime)
BEGIN
    SELECT SUM(Profit * Ownership) AS Profit FROM Trade
    INNER JOIN Claim ON Trade.Id = Claim.TradeId
    INNER JOIN Account ON Claim.AccountId = Account.Id
    INNER JOIN User ON User.Id = Account.Id
    WHERE ExitTime > StartDate AND ExitTime < EndDate AND User.Id = UserID
    GROUP BY Account.Id;
END;

