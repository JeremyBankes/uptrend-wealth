create
    definer = admin@`%` procedure GetCountries()
BEGIN
    SELECT * FROM Country;
END;

