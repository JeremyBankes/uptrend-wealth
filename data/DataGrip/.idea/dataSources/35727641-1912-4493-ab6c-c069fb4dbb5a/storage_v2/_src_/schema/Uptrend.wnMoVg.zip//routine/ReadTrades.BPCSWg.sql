create
    definer = admin@`%` procedure ReadTrades()
BEGIN
    SELECT * FROM Trade;
END;

