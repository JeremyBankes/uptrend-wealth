create
    definer = admin@`%` procedure GetTransfer(IN UserId int, IN StartDate datetime, IN EndDate datetime,
                                              IN IsContribution bit)
BEGIN
IF IsContribution = 1 THEN
    SELECT Transfer.Id AS TransferId, Amount, Time FROM Transfer
    INNER JOIN Account ON Transfer.AccountId = Account.Id
    INNER JOIN User ON Account.Id = User.AccountId
    WHERE User.Id = 1 AND Time > StartDate AND Time < EndDate AND Amount > 0;
ELSE
    SELECT Transfer.Id AS TransferId, Amount, Time FROM Transfer
    INNER JOIN Account ON Transfer.AccountId = Account.Id
    INNER JOIN User ON Account.Id = User.AccountId
    WHERE User.Id = 1 AND Time > StartDate AND Time < EndDate AND Amount < 0;
END IF;
END;

