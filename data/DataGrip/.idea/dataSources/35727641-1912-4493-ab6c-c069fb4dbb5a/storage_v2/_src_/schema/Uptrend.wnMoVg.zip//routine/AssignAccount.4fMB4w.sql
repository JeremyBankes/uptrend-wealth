create
    definer = admin@`%` procedure AssignAccount(IN UpdatedAccountId int, IN UserId int)
BEGIN
    UPDATE User SET User.AccountId = UpdatedAccountId
    WHERE User.Id = UserId;
END;

