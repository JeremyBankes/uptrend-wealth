create
    definer = admin@`%` procedure AssignAccount(IN UserId int, IN AccountId int)
BEGIN
    UPDATE User SET User.AccountId = AccountId WHERE User.Id = UserId;
END;

