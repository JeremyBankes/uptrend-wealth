create
    definer = admin@`%` procedure CreateUser(IN FirstName varchar(128), IN LastName varchar(128), IN Email varchar(256),
                                             IN Hash binary(72), IN Phone varchar(64), IN Registration datetime,
                                             IN AddressId int, OUT UserId int)
BEGIN
    INSERT INTO User (FirstName, LastName, Email, Hash, Phone, Registration, AddressId)
    VALUES (FirstName, LastName, Email, Hash, Phone, Registration, AddressId);
    SET UserId = LAST_INSERT_ID();
END;

