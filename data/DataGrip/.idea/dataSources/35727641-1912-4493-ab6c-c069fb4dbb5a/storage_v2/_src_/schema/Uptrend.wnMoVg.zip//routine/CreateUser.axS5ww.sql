create
    definer = admin@`%` procedure CreateUser(IN FirstName varchar(128), IN LastName varchar(128), IN Email varchar(256),
                                             IN Hash binary(72), IN Phone varchar(64), IN Registration datetime,
                                             IN AddressId int)
BEGIN
    INSERT INTO User (FirstName, LastName, Email, Hash, Phone, Registration, AddressId)
    VALUES (FirstName, LastName, Email, Hash, Phone, Registration, AddressId);
END;

