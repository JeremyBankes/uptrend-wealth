create
    definer = admin@`%` procedure CreateAccount(IN CloseDate datetime, OUT Id int)
BEGIN
    INSERT INTO Account (CloseDate)
    VALUES (CloseDate);
    SET Id = LAST_INSERT_ID();
END;

