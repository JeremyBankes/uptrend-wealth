create
    definer = admin@`%` procedure ReadUser(IN Id int, IN Email varchar(256))
BEGIN
    IF Id IS NOT NULL THEN
        SELECT * FROM User WHERE User.Id = Id;
    ELSEIF Email IS NOT NULL THEN
        SELECT * FROM User WHERE LOWER(User.Email) = LOWER(Email);
    END IF;
END;

