create
    definer = admin@`%` procedure ReadUser(IN Id int, IN Email varchar(256))
BEGIN
    SELECT * FROM User WHERE User.Id = Id OR User.Email = Email LIMIT 1;
END;

