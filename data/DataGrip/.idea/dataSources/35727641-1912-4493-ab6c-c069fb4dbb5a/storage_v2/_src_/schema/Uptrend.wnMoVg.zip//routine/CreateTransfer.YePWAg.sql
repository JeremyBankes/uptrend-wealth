create
    definer = admin@`%` procedure CreateTransfer(IN Amount decimal(13, 4), IN AccountId int, IN Time datetime)
BEGIN
    INSERT INTO Transfer (Amount, AccountId, Time)
    VALUES (Amount, AccountId, Time);
    SELECT LAST_INSERT_ID() AS Id;
END;

