create
    definer = admin@`%` procedure CreateTransfer(IN Amount decimal(13, 4), IN AccountId int, IN Time datetime,
                                                 OUT Id int)
BEGIN
    INSERT INTO Transfer (Amount, AccountId, Time)
    VALUES (Amount, AccountId, Time);
    SET Id = LAST_INSERT_ID();
END;

