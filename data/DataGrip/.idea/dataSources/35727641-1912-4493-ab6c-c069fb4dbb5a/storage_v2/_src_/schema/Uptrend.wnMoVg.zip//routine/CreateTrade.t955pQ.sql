create
    definer = admin@`%` procedure CreateTrade(IN Pair char(6), IN EntryPrice decimal(13, 4), IN EntryTime datetime,
                                              IN ExitPrice decimal(13, 4), IN ExitTime datetime,
                                              IN Direction tinyint(1), IN InitialStopPrice decimal(13, 4),
                                              IN PositionSize int, IN FundSize decimal(13, 4), IN Profit decimal(13, 4),
                                              OUT Id int)
BEGIN
    INSERT INTO Trade (Pair, EntryPrice, EntryTime, ExitPrice, ExitTime, Direction, InitialStopPrice, PositionSize, FundSize, Profit)
    VALUES (Pair, EntryPrice, EntryTime, ExitPrice, ExitTime, Direction, InitialStopPrice, PositionSize, FundSize, Profit);
    SET Id = LAST_INSERT_ID();
END;

