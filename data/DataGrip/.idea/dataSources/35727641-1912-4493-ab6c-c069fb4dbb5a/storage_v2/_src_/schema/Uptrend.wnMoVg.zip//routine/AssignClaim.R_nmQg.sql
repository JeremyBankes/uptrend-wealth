create
    definer = admin@`%` procedure AssignClaim(IN UserId int, IN TradeId int, IN Ownership decimal(5, 4))
BEGIN
    SELECT @AccountId := User.AccountId FROM User WHERE User.Id = UserId;
    INSERT INTO Claim (AccountId, TradeId, Ownership)
    VALUES (@AccountId, TradeId, Ownership);
    SELECT LAST_INSERT_ID() AS Id;
END;

