create
    definer = admin@`%` procedure CreateAccount()
BEGIN
    INSERT INTO Account () VALUES ();
    SELECT LAST_INSERT_ID() AS Id;
END;

