create
    definer = admin@`%` procedure Balance(IN UserId int)
BEGIN
    SELECT (SELECT SUM (Ownership * Profit) AS TradeProfit FROM User
        INNER JOIN Account ON User.AccountId = Account.Id
        INNER JOIN Claim ON Account.Id = Claim.AccountId
        INNER JOIN Trade ON Claim.TradeId = Trade.Id
        WHERE User.Id = UserId
        GROUP BY Account.Id) + (SELECT SUM(Amount) AS Contribution FROM User
        INNER JOIN Account ON User.AccountId = Account.Id
        INNER JOIN Transfer ON Account.Id = Transfer.AccountId
        WHERE User.Id = UserId
        GROUP BY Account.Id);
END;

