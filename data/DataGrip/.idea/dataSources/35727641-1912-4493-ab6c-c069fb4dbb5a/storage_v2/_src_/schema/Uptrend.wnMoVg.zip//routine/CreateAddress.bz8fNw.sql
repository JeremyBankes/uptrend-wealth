create
    definer = admin@`%` procedure CreateAddress(IN StreetAddress varchar(256), IN Subdivision varchar(256),
                                                IN City varchar(256), IN ZipCode varchar(10), IN CountryId int,
                                                OUT AddressId int)
BEGIN
    INSERT INTO Address (StreetAddress, Subdivision, City, ZipCode, CountryId)
    VALUES (StreetAddress, Subdivision, City, ZipCode, CountryId);
    SET AddressId = LAST_INSERT_ID();
END;

