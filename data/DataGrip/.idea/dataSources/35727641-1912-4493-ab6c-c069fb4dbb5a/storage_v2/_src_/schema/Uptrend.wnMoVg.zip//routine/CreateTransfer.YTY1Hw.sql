create
    definer = admin@`%` procedure CreateTransfer(IN UserId int, IN Amount decimal(13, 4), IN Time datetime)
BEGIN
    SELECT @AccountId := User.AccountId FROM User WHERE User.Id = 3;
    INSERT INTO Transfer (Amount, AccountId, Time)
    VALUES (Amount, @AccountId, Time);
    SELECT LAST_INSERT_ID() AS Id;
END;

