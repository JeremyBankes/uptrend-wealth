create
    definer = admin@`%` procedure CreateClaim(IN AccountId int, IN TradeId int, IN Ownership decimal(5, 4))
BEGIN
    INSERT INTO Claim (AccountId, TradeId, Ownership)
    VALUES (AccountId, TradeId, Ownership);
END;

